﻿using Npgsql;

using System;
using System.Configuration;

namespace wgvmi
{
    public partial class teste : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["PostgreSQLConn"].ConnectionString;

            using (NpgsqlConnection connection = new NpgsqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    resultLabel.Text = "Conexão bem-sucedida com o banco de dados PostgreSQL!";
                }
                catch (Exception ex)
                {
                    resultLabel.Text = "Erro ao conectar ao banco de dados: " + ex.Message;
                }
            }
        }
    }
}